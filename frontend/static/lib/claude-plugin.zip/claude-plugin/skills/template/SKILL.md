---
name: template
description: How to write a TaskManager board TEMPLATE — a few lines of JavaScript that shape a board's own UI: a message template (a form in the composer whose submit posts a message), a ticket template (a form in New ticket whose submit creates a ticket) or a card template (what each kanban card shows). Use whenever the user asks for a form, a message or ticket template, "a bug report form", dependent dropdowns, a custom card or card preview on a TaskManager board, or mentions template_save, list_templates or cardTemplateId.
---

# TaskManager templates

Version 2.2.0 · updated 2026-10-17 · this deployment: https://taskmanager-example.web.app

The steps, every time:

```text
1. read      get_template_docs (this text + a starter per kind) and list_templates { include_code: true }
             — change an existing template rather than adding a near-copy
2. look      get_board_settings: the stages, priorities, tags and custom fields to name (by name is fine)
3. write     template_save { board, template: { kind, name, description, code } }
             — templateId to update one; a template keeps its kind; only board admins may
4. use it    card templates: view_save with view.cardTemplateId on a kanban view
5. tell      the person where it shows: the composer's 📋, New ticket, or the view — and that
             Settings › Templates has a live preview where they can try it
```

Write `description` for people and agents ("Steps, severity and environment for a bug"). Keep the code
small and readable — the board's admins maintain it after you.

The full reference — also §9 of `../taskmanager/reference/llms-full.txt`, live at https://taskmanager-example.web.app/llms-full.txt:

**Forms and cards are now written in the board script** (*Board script*: `forms()` for the
composer's 📋 and *New ticket*, `previewTicketCard` for the Board view's cards). The app no longer
offers separate message, ticket or card templates. What follows still applies to the script: how
the code runs, the builder `h` its trees are drawn with, `api`, and what a form's submit answers.

The board script is stored as the template `script` (`boards/{b}/templates/script`),
100,000 characters of code at most. Admins (people or agents) change it in
*Board settings › Script*, with `template_save` over MCP or `POST /api/templateSave`. Copying a board
copies it. (Up to 50 templates of the old kinds may still be stored; the app does not use them.)

### How it runs

The code never runs in the app's page. Each person's browser starts it in a **Web Worker
with an opaque origin** (a `data:` URL): no cookies, no IndexedDB or localStorage, no
same-origin requests, no access to the page. Your code computes; the app draws.

* `render` returns a **tree** built with `h`. The app draws it on the main thread and,
  on every re-render, **patches** the page instead of rebuilding it: an element keeps its
  DOM node while its type and position (or its `key`) stay the same, so the input you are
  typing in keeps its focus and caret while the form changes around it.
* `false`, `null` and `''` in a child list are **holes** that keep their slot —
  `cond && h.select(…)` appearing never moves the fields after it.
* A **controlled** input (`value` given) is only overwritten when the worker has seen your
  last keystroke from it, so typing fast never loses characters.
* The worker is pinged every second; three seconds without an answer (an endless loop)
  and it is stopped, with an error in the form.
* `fetch()` to the open web works (CORS applies). The app's own API is reachable only
  through `api` below.

### The module

```js
export default {
  // optional — the first state; may be async; gets ctx
  state: (ctx) => ({ kind: 'bug', steps: '' }),

  // required — draw the state. Called again after every setState.
  render(state, setState, h, ctx) {
    return h.col(/* … */);
  },

  // message and ticket templates — what the form sends (see "submit")
  submit(state, ctx) {
    return { type: 'valid', msg: 'Hello' };
  },
};
```

* Exactly one `export default`. No `import` — the builder `h`, `api` and `console`
  are given to you. `export default function render(…)` is a card template with only render.
* `setState(patch)` merges an object into the state (or takes `(state) => patch`) and
  re-renders on the next microtask; several calls render once.
* Handlers (`onInput`, `onChange`, `onClick` …) may be `async`; call `setState` when done.
* `console.log/warn/error` print to the editor's Console.
* An error (compile, `state`, `render`, a handler, `submit`) shows in the form with its
  **line number**; in the editor the line is a button that jumps to it.

### ctx

| field | what |
| --- | --- |
| `ctx.kind` | `'message' \| 'ticket' \| 'card'` |
| `ctx.board` | `{ id, key, name, description, stages[], priorities[], tags[], fields[] }` — options are `{ id, name, color }`, stages add `category`, fields are `{ id, name, type, required, options[] }` |
| `ctx.me` | the person (or agent) looking: `{ id, name, email, role }` |
| `ctx.ticket` | message templates: the ticket whose thread it is; card templates: the card's ticket (below) |
| `ctx.api` | the same `api` as the global |

A **ticket** (`ctx.ticket`, `api.tickets.*`) is
`{ id, key, title, description, stage, priority, tags[], assignees[], reporter, state, dueAt,
dueAllDay, startAt, estimate, fields, fieldValues, counts: { messages, files }, tasks,
createdAt, updatedAt, completedAt }` — `description` is plain text, `stage` / `priority` /
`tags` are `{ id, name, color }`, `assignees` are members `{ id, kind, name, email, role }`,
dates are milliseconds, `fields` is **by field name** with readable values (option names,
member names) and `fieldValues` **by field id** as stored, `tasks` is `{ done, total }` or null.

### api

Every call is answered by the app **as the person looking, for this board only** — a
template sees what that person could see on this board anyway, and nothing else. All
calls return promises.

| call | answers |
| --- | --- |
| `api.board()` | the board, as `ctx.board` |
| `api.me()` | as `ctx.me` |
| `api.members()` | everyone on the board: `{ id, kind: 'user' \| 'agent', name, email, role }[]` |
| `api.tickets.get(key)` | one ticket of this board by key (`'ENG-42'`), or null |
| `api.tickets.list({ stage?, assignee?, tag?, priority?, text?, limit? })` | active tickets, newest change first; filters take ids or names, `assignee` also an email or `'me'`; `limit` ≤ 200 (default 50) |
| `api.tickets.search(text, { limit? })` | best matches by key and title |
| `api.storage.get(key)` / `api.storage.set(key, value)` | this person's own small store for this template (JSON, ≤ 10 000 characters a key; `null` deletes) — e.g. remember the last choice |

A template never writes through `api`. The only thing it sends is its `submit`
answer, and only when the person presses **Send** / **Create ticket**.

### The builder h

Containers take `(props?, ...children)`; children are nodes, strings, numbers, arrays,
or holes. Every node takes `key` (keeps it across re-renders — use it in `.map`),
`style` (an object of CSS; `url()` is refused) and `title` (a tooltip).

| node | props |
| --- | --- |
| `h.col(…)` `h.row(…)` `h.grid(…)` `h.div(…)` | `gap` (×0.25rem), `align` (start · center · end · stretch · baseline), `justify` (start · center · end · between · around), `wrap` (row), `cols` (grid, 1–12), `padding`, `border`, `bg` (surface · muted · accent · success · warning · danger), `tone`, `size` |
| `h.text(str, props?)` | `tone` (default · muted · subtle · accent · success · warning · danger), `size` (xs · sm · md · lg · xl), `weight` (normal · medium · semibold · bold), `mono`, `italic`, `strike`, `truncate`, `block`, `color` (#hex); or `h.text(props, ...children)` |
| `h.heading(str, { level })` | level 1–4 |
| `h.markdown(md)` | GitHub Markdown, sanitised (`#KEY` links to the ticket) |
| `h.badge(str, { tone, color })` | a pill |
| `h.divider()` | a rule |
| `h.link(label, { href })` | http(s), mailto or an app path; outside links open a new tab |
| `h.image({ src, alt, width, height, radius })` | https or inline png/jpeg/gif/webp |
| `h.person(id, { size, showName })` | a member's picture and name |
| `h.ticket(key, { label })` | a ticket chip that opens it |
| `h.progress({ value, max, color })` | a bar |
| `h.input({ label, name, value, type, placeholder, hint, error, required, disabled, min, max, step, onInput, onChange, onEnter })` | `type`: text · number · email · url · tel · date · datetime-local · time · password · search · color; handlers get `(value, { name })` — a number input's value is a number or null |
| `h.textarea({ label, name, value, rows, placeholder, hint, error, onInput, onChange })` | |
| `h.select({ label, name, value, options, placeholder, multiple, onChange })` | `options`: strings or `{ value, label, disabled }`; `placeholder` adds an empty first option; `multiple` gives and takes an array |
| `h.radio({ label, name, value, options, onChange })` | a radio group |
| `h.checkbox({ label, name, checked, hint, onChange })` | `onChange(checked)` |
| `h.button(label, { variant, size, disabled, onClick })` | variant: primary · secondary · ghost · danger; size: sm · md |
| `h.el(tag, props?, ...children)` | plain elements: div span p b strong i em u s small code pre kbd mark blockquote ul ol li dl dt dd h1–h6 hr br table thead tbody tr th td caption label section header footer figure figcaption sup sub details summary |

A field's `name` ties it to `submit`'s errors: `{ type: 'invalid', error: { steps: 'Required' } }`
shows *Required* under the input named `steps`.

### submit

`submit(state, ctx)` may be async. It answers one of:

```js
{ type: 'invalid', errMsg: 'Fill in the steps', error: { steps: 'Required' } } // the form stays open
{ type: 'valid', msg: '**Bug** · high', data: { severity: 'high' } }          // message templates
{ type: 'valid', ticket: { title: 'Dark mode', stage: 'To do', tags: ['ui'] } } // ticket templates
```

**Message templates**: `msg` is Markdown (mention people as `@email`, tickets as `#KEY`).
`data` (any JSON, ≤ 16,000 characters) is stored on the message as
`template: { id, name, data }` — REST and MCP return it, so an agent reads the form's answer
instead of parsing the text.

**Ticket templates**: `ticket` is
`{ title, description?, stage?, priority?, tags?, assignees?, dueAt?, dueAllDay?, startAt?, estimate?, fields? }`.
Name things the way people do — a stage, priority or tag by id **or name**, people by id,
**email** or name, `fields` by field id or **name** (select options by id or name), dates as
milliseconds, `'2026-10-20'`, `'fri'`, `'+3d'` or an ISO date-time. A tag name the board lacks
becomes a new tag; anything else that names nothing is shown as a problem and nothing is
created. The board's required fields must be set. Without `stage` the ticket goes where the
dialog was opened (the column's +), else the first stage.

### Over MCP

`get_template_docs` (this text and the *Board script* reference, with the default script),
`list_templates` (with `include_code`), and `template_save`
(`{ board, template: { kind: 'script', name, code } }` — the board script is always the template
`script`). Messages read with `get_messages` carry `template` when a form wrote them.

